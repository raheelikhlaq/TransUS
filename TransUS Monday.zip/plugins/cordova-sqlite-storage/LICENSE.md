# Licenses

## Common Javascript

MIT or Apache 2.0

## for browser platform

MIT or Apache 2.0

### sql.js

MIT

## for Android

MIT or Apache 2.0

### Android-sqlite-connector

Unlicense (public domain)

### Android-sqlite-ext-native-driver

Unlicense (public domain)

## for iOS & macOS

MIT only

based on Phonegap-SQLitePlugin by @davibe (Davide Bertola <dade@dadeb.it>) and @joenoon (Joe Noon <joenoon@gmail.com>)

includes and uses PSPDFThreadSafeMutableDictionary (PSPDFThreadSafeMutableDictionary.m <https://gist.github.com/steipete/5928916>) MIT license by @steipete (<https://gist.github.com/steipete>)

## for Windows

MIT or Apache 2.0

### SQLite3-WinRT

by @doo (doo GmbH)

MIT License

## Common native code

### SQLite3

Public domain
